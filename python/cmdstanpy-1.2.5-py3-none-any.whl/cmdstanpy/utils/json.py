"""
Delegated to stanio - https://github.com/WardBrian/stanio
"""
from stanio import write_stan_json

__all__ = ['write_stan_json']
