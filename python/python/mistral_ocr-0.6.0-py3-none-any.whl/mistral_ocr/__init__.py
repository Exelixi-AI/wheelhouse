"""Mistral OCR package for text extraction from images."""

__version__ = "0.5.0" 